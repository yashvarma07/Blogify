package com.blogify.entry.controllers;

import com.blogify.entry.dtos.postDtos.PostResponseDto;
import com.blogify.entry.dtos.userDto.UserPartialRequestDto;
import com.blogify.entry.dtos.userDto.UserRequestDto;
import com.blogify.entry.dtos.userDto.UserResponseDto;
import com.blogify.entry.enteties.User;
import com.blogify.entry.services.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RequestMapping("/user")
@RestController
public class     UserController {

    @Autowired
    UserService userService;

    @GetMapping
    public ResponseEntity<Page<UserResponseDto>> getAllUsers(
            @RequestParam(defaultValue = "0")int page,
            @RequestParam(defaultValue = "2")int size,
            @RequestParam(defaultValue = "ASC")String sortDirection,
            @RequestParam(defaultValue = "id")String sortBy
    ) {
        Page<UserResponseDto> alUsers = userService.getAll(page, size, sortDirection, sortBy).map
                (user -> userService.convertToUserResponseDto(user));
        return ResponseEntity.ok(alUsers);
    }

    @PostMapping
    public ResponseEntity<UserResponseDto> createUser(@Valid @RequestBody UserRequestDto userRequestDto){
        User user = userService.convertToUser(userRequestDto);
        User createdUser = userService.create(user);
        UserResponseDto userResponseDto = userService.convertToUserResponseDto(createdUser);
       return ResponseEntity.status(201).body(userResponseDto);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserResponseDto> getUserById(@PathVariable int id){
        User user = userService.getById(id);
        UserResponseDto userResponseDto = userService.convertToUserResponseDto(user);
        return ResponseEntity.ok(userResponseDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UserResponseDto> updateUserById(@Valid @PathVariable int id, @RequestBody UserPartialRequestDto userPartialRequestDto){
        User user = userService.convertToUser(userPartialRequestDto);
        User updatedUser = userService.update(id,user);
        UserResponseDto userResponseDto = userService.convertToUserResponseDto(updatedUser);
        return ResponseEntity.ok(userResponseDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<UserResponseDto> deleteUserById(@PathVariable int id){
        userService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
