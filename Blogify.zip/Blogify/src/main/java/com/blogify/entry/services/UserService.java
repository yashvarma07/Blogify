package com.blogify.entry.services;

import com.blogify.entry.configurations.SecurityConfiguration;
import com.blogify.entry.dtos.userDto.UserPartialRequestDto;
import com.blogify.entry.dtos.userDto.UserRequestDto;
import com.blogify.entry.dtos.userDto.UserResponseDto;
import com.blogify.entry.enteties.Post;
import com.blogify.entry.enteties.Role;
import com.blogify.entry.enteties.User;
import com.blogify.entry.repositories.RoleRepository;
import com.blogify.entry.repositories.UserRepository;
import jakarta.persistence.NamedAttributeNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
            @Lazy
    PostService postService;

    @Autowired
    PasswordEncoder passwordEncoder;

    public User create(User user){
        if(userRepository.findByUsername(user.getUsername()).isPresent()){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User alread exists");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        Role userRole =roleRepository.findByName("ROLE_USER").get();
//        Role userRole = roleRepository.findByName("ROLE_USER")
//                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Role ROLE_USER not found"));

        user.getRoles().add(userRole);
        return userRepository.save(user);
    }
//public User create(User user) {
//    if (userRepository.findByUsername(user.getUsername()).isPresent()) {
//        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User already exists");
//    }
//    user.setPassword(passwordEncoder.encode(user.getPassword()));
//    Role userRole = roleRepository.findByName("ROLE_USER")
//            .orElseGet(() -> {
//                Role newRole = new Role();
//                newRole.setName("ROLE_USER");
//                return roleRepository.save(newRole);
//            });
//    user.getRoles().add(userRole);
//    return userRepository.save(user);
//}

    public User createAdmin(){
        Optional<User>existingUser = userRepository.findByUsername("root");

        if (existingUser.isPresent()){
            return existingUser.get();
        }
        User user = new User();
        user.setUsername("root");
        user.setPassword(passwordEncoder.encode("112233aa"));
        Role userRole = roleRepository.findByName("ROLE_ADMIN").get();
//        Role userRole = roleRepository.findByName("ROLE_ADMIN").orElseThrow(() -> new RuntimeException("ROLE_ADMIN not found"));
        user.getRoles().add(userRole);
        user.setEmail("root@gmail.com");
        return userRepository.save(user);
    }
//public User createAdmin() {
//    Optional<User> existingUser = userRepository.findByUsername("root");
//    if (existingUser.isPresent()) {
//        return existingUser.get();
//    }
//    User user = new User();
//    user.setUsername("root");
//    user.setPassword(passwordEncoder.encode("112233aa"));
//    Role userRole = roleRepository.findByName("ROLE_ADMIN")
//            .orElseGet(() -> {
//                Role newRole = new Role();
//                newRole.setName("ROLE_ADMIN");
//                return roleRepository.save(newRole);
//            });
//    user.getRoles().add(userRole);
//    user.setEmail("root@gmail.com");
//    return userRepository.save(user);
//}

    public Page<User> getAll(int page, int size, String sortDirection,String sortBy){
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.fromString(sortDirection), sortBy));
        return userRepository.findAll(pageable);
    }

    public User getById(int id){
        return userRepository.findById(id).orElseThrow(
                ()->new ResponseStatusException(HttpStatus.NOT_FOUND));//Not complete message not added
    }

    public User update(int id, User user){
        User existingUser = getById(id);
        if (user.getUsername() != null){
            existingUser.setUsername(user.getUsername());
        }
        if (user.getPassword() != null){
            existingUser.setPassword(user.getPassword());
        }
        if (user.getEmail() !=null){
            existingUser.setEmail(user.getEmail());;
        }
        return userRepository.save(existingUser);
    }

    public void delete(int id){
        User user = getById(id);
        List<Post> postCopy = new ArrayList<>(user.getPosts());
        for (Post post : postCopy){
            postService.delete(post.getId(), user.getId());
            user.getPosts().remove(post);
        }
        userRepository.save(user);
        userRepository.deleteById(id);
    }

    public User convertToUser(UserRequestDto userRequestDto){
        User user = new User();
        user.setUsername(userRequestDto.getUsername());
        user.setPassword(userRequestDto.getPassword());
        user.setEmail(userRequestDto.getEmail());
        return user;
    }

    public User convertToUser(UserPartialRequestDto userPartialRequestDto){
        User user = new User();
        user.setUsername(userPartialRequestDto.getUsername());
        user.setPassword(userPartialRequestDto.getPassword());
        user.setEmail(userPartialRequestDto.getEmail());
        return user;
    }

    public UserResponseDto convertToUserResponseDto(User user){
        UserResponseDto userResponseDto= new UserResponseDto();
        userResponseDto.setId(user.getId());
        userResponseDto.setUsername(user.getUsername());
        userResponseDto.setPassword(user.getPassword());
        userResponseDto.setEmail(user.getEmail());
        userResponseDto.setCreatedDate(user.getCreatedDate());
        userResponseDto.setLastModifiedDate(user.getLastModifiedDate());
        return  userResponseDto;
    }

    public User getByUserName(org.springframework.security.core.userdetails.User user){
        return userRepository.findByUsername(user.getUsername())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User with username : "+ user.getUsername() + " not found"));
    }

}
