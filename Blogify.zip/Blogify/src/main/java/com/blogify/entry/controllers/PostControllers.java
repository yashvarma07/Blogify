package com.blogify.entry.controllers;

import com.blogify.entry.enteties.Post;
import com.blogify.entry.enteties.Tag;
import com.blogify.entry.repositories.UserRepository;
import com.blogify.entry.services.PostService;
import com.blogify.entry.dtos.postDtos.PostRequestDtos;
import com.blogify.entry.dtos.postDtos.PostResponseDto;
import com.blogify.entry.services.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/posts")
public class PostControllers {

    final private PostService postServices;
    private final UserService userService;

    @Autowired
    private ObjectMapper objectMapper;

    PostControllers(PostService postService, UserService userService) {
        this.postServices = postService;
        this.userService = userService;
    }

    @GetMapping("")
    public ResponseEntity<Page<PostResponseDto>> getAllPosts(
            @RequestParam(defaultValue = "0")int page,
            @RequestParam(defaultValue = "2")int size,
            @RequestParam(defaultValue = "ASC")String sortDirection,
            @RequestParam(defaultValue = "id")String sortBy
    ){
        Page<PostResponseDto> posts = postServices.getAll(page,size,sortDirection,sortBy).map
                (post ->postServices.convertToPostResponseDtos(post));
        return ResponseEntity.ok(posts);
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PostResponseDto> createPost(
            @RequestPart(name = "post", required = true)
               @Valid @NotNull String postRequestDtoString,
            @RequestPart(name = "image") MultipartFile image,
            @AuthenticationPrincipal User user){
                PostRequestDtos postRequestDtos = null;
                try {
                    postRequestDtos = objectMapper.readValue(postRequestDtoString, PostRequestDtos.class);
                }catch (JsonProcessingException e){
                    throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "inavlid post data");
                }
        Post createdPost= postServices.create(postServices.covertToPost(postRequestDtos), image ,userService.getByUserName(user).getId());
        return  ResponseEntity.status(201).body(postServices.convertToPostResponseDtos(createdPost));
    }

    @GetMapping("/search")
    public ResponseEntity<List<PostResponseDto>> searchPosts(@RequestParam String value){
        List<Post> searchResults = postServices.search(value);
        List<PostResponseDto> Posts = searchResults.stream().map(postServices::convertToPostResponseDtos).toList();
        return ResponseEntity.ok().body(Posts);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PostResponseDto> getPostById(@PathVariable int id){
        return  new ResponseEntity<PostResponseDto>(postServices.convertToPostResponseDtos(postServices.getPost(id)), HttpStatus.OK);
    }

    @GetMapping("/title")
    public ResponseEntity <List<PostResponseDto>> getPostByTitle(@RequestParam String value){
        return new ResponseEntity<List<PostResponseDto>>(postServices.getByTitle(value).stream().map
                (post->postServices.convertToPostResponseDtos(post)).collect(Collectors.toList()), HttpStatus.OK);
    }

    @GetMapping("/tag")
    public ResponseEntity <List<PostResponseDto>> getPostByTagName(@RequestParam String value){
        return new ResponseEntity<List<PostResponseDto>>(postServices.getByTagName( value).stream().map
                (post->postServices.convertToPostResponseDtos(post)).collect(Collectors.toList()), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PostResponseDto> updatePostById(@PathVariable int id,@RequestBody PostRequestDtos postRequestDtos,@AuthenticationPrincipal User user){
        Post updatedPost = postServices.update(id, postServices.covertToPost(postRequestDtos),userService.getByUserName(user).getId());
        return ResponseEntity.ok(postServices.convertToPostResponseDtos(updatedPost));
    }

    @PatchMapping("/{id}")
    public  ResponseEntity<PostResponseDto>  updatePartialPostById(@PathVariable int id, @RequestBody PostRequestDtos postRequestDtos, @AuthenticationPrincipal User user){
        Post updatedPost = postServices.update(id, postServices.covertToPost(postRequestDtos), userService.getByUserName(user).getId());
        return ResponseEntity.ok(postServices.convertToPostResponseDtos(updatedPost));
    }

    @DeleteMapping("/{id}")
    public  ResponseEntity<?> deletePostById(@PathVariable int id,@AuthenticationPrincipal User user){
        postServices.delete(id,userService.getByUserName(user).getId());
        return  ResponseEntity.noContent().build();
    }

    @GetMapping("/user/all")
    public ResponseEntity<List<PostResponseDto>> getUserPosts(@AuthenticationPrincipal User user){
        List<PostResponseDto> posts = postServices.userPosts(userService.getByUserName(user).getId())
                .stream()
                .map(postServices :: convertToPostResponseDtos).collect(Collectors.toList());
        return ResponseEntity.ok(posts);
    }


}
