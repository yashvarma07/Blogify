package com.blogify.entry.services;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

@Service
public class ImageService {

    private static final String BASE_URL = "http://localhost:8081/dev/api/bloghive";
    private static final String IMAGE_DIRECTORY = "src/main/resouces/static/Images/posts";
    private static final String IMAGE_URL = "images/posts/";

    @PostConstruct
    public void intit() {
        Path directoryPath = Paths.get(IMAGE_DIRECTORY);
        if (Files.notExists(directoryPath)) {
            try {
                Files.createDirectories(directoryPath);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public String saveImage(MultipartFile image) throws IOException, NoSuchAlgorithmException {
        String uniqueFileName = generateUniqueFileName(image.getOriginalFilename());
        Path filePath = Paths.get(IMAGE_DIRECTORY, uniqueFileName);
        Files.write(filePath, image.getBytes());

//        Convert to file path to a URL format
        String fileURl = BASE_URL + IMAGE_URL + uniqueFileName;
        return fileURl;
    }

    public String generateUniqueFileName(String originalFilename) throws NoSuchAlgorithmException {
        String timestamp = String.valueOf(System.currentTimeMillis());
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest((originalFilename + timestamp).getBytes());
        return Base64.getUrlEncoder().encodeToString(hash) + getFileExtention(originalFilename);
    }

    public String getFileExtention(String filename) {
        return filename.contains(".") ? filename.substring(filename.lastIndexOf(".")) : "";
    }


}
