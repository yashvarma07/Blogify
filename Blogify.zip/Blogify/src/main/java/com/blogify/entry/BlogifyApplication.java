package com.blogify.entry;

import com.blogify.entry.enteties.Role;
import com.blogify.entry.repositories.RoleRepository;
import com.blogify.entry.services.UserService;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@SpringBootApplication
@EntityScan(basePackages = "com.blogify.entry.enteties")
public class BlogifyApplication {

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	UserService userService;

	public static void main(String[] args) {
		SpringApplication.run(BlogifyApplication.class, args);
	}

	@PostConstruct
	@Transactional
	public void init(){
//		userService.createAdmin();
		Set<String> requiredRoles = Set.of("ROLES_USER" , "ROLES_ADMIN");
		List<Role> existingRoles = roleRepository.findByNameIn(requiredRoles);

		if (existingRoles.size() < requiredRoles.size()){
			List<Role> roleToSave = requiredRoles.stream().filter(roleName ->
					existingRoles.stream().noneMatch(role-> role.getName().equals(roleName)))
					.map(roleName -> {
						Role role = new Role();
						role.setName(roleName);
						return role;
					}).toList();
			if (!roleToSave.isEmpty()){
				roleRepository.saveAll(roleToSave);
			}
			userService.createAdmin();
		}
	}
}
