package com.blogify.entry.dtos.postDtos;

import com.blogify.entry.dtos.userDto.UserAuthorResponseDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.awt.*;
import java.time.LocalDateTime;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PostResponseDto {

    private int id;
    private String title;
    private String descirption;
    private Set<String> tags;
    private LocalDateTime createdDated;
    private LocalDateTime lastModifiedDate;
    private UserAuthorResponseDto author;
    private String  ImageUrl;
}
