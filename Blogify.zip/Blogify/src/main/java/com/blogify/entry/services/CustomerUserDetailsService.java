package com.blogify.entry.services;

import com.blogify.entry.enteties.User;
import com.blogify.entry.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

/**
 * Custom implementation of Spring Security's UserDetailsService to load user details
 * from the database using a UserRepository. This service retrieves user information
 * by username for authentication purposes.
 */
@Service
public class CustomerUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    /**
     * Loads user details by username from the database.
     *
     * @param username The username identifying the user to be loaded.
     * @return UserDetails containing the user's credentials and authorities.
     * @throws UsernameNotFoundException If no user is found with the given username.
     */

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException{
        User user = userRepository.findByUsername(username).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User with Username: " + username + " not found."));
        System.out.println(user.getUsername());
        System.out.println(user.getPassword());
        System.out.println(user.getRoles());
        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getUsername())
                .password(user.getPassword())
                .authorities(user.getRoles().stream().map(role->new SimpleGrantedAuthority(role.getName())).toList())
               .build();
}
}