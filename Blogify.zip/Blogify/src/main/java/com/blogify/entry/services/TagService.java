package com.blogify.entry.services;

import com.blogify.entry.dtos.tagDto.TagRequestDto;
import com.blogify.entry.dtos.tagDto.TagResponseDto;
import com.blogify.entry.enteties.Tag;
import com.blogify.entry.repositories.PostRepositories;
import com.blogify.entry.repositories.TagsRepositories;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class TagService {
    @Autowired
    TagsRepositories tagsRepositories;

    @Autowired
    PostRepositories postRepositories;

    public List<Tag> getALl(){
        return tagsRepositories.findAll();
    }

    public Tag create(Tag tag){
        if (tagsRepositories.findByName(tag.getName()).isPresent()){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Tag with name : "+ tag.getName()+ " already exists you cannot duplicate tags .");
        }
        return tagsRepositories.save(tag);
    }

    public Tag update(String oldTagName, Tag tag){
        String newTagName = tag.getName();
        if (oldTagName.equals(newTagName)){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "You cannot update same tag name");
        }

        Tag existingTag = tagsRepositories.findByName(oldTagName).orElseThrow(()->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Tag with name : "+ oldTagName+" not found in the database"));

        if (tagsRepositories.findByName(newTagName).isPresent()){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "You cannot update from" +oldTagName+ " to " +newTagName+ " because " +newTagName+ " alreasy exist in the database");
        }
        existingTag.setName(newTagName);
        return tagsRepositories.save(existingTag);
    }

    public  void  delete(String tagName){
        Tag tag = tagsRepositories.findByName(tagName).orElseThrow(()->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Tag name with name : " +tagName+ " not found"));

        if (postRepositories.findByTagsName(tagName).isEmpty()){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "You cannot delete tag name : " +tagName+ " because there are same posts which have its refrences");
        }
        tagsRepositories.delete(tag);
    }

    public TagResponseDto convertToTagResponseDto(Tag tag){
        return new TagResponseDto(tag.getId(),tag.getName());
    }

    public Tag convertToTag(TagRequestDto tagRequestDto){
        return new Tag(0,tagRequestDto.getName());
    }
}
