package com.blogify.entry.controllers;

import com.blogify.entry.dtos.tagDto.TagRequestDto;
import com.blogify.entry.dtos.tagDto.TagResponseDto;
import com.blogify.entry.enteties.Tag;
import com.blogify.entry.services.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/tags")
public class TagController {
    @Autowired
    TagService tagService;

    @GetMapping("")
    public ResponseEntity<List<TagResponseDto>> getAllTags(){
        return new ResponseEntity<>(tagService.getALl().stream().map(tag ->
                tagService.convertToTagResponseDto(tag)).collect(Collectors.toList()), HttpStatus.OK);
    }
     @PostMapping("")
    public ResponseEntity<TagResponseDto> createTag(@RequestBody TagRequestDto tagRequestDto){
         Tag tag= tagService.convertToTag(tagRequestDto);
         Tag createdTag= tagService.create(tag);
         return new ResponseEntity<TagResponseDto>(tagService.convertToTagResponseDto(createdTag), HttpStatus.CREATED);
     }

     @PutMapping("/{tagname}")
    public ResponseEntity<TagResponseDto> updateTag(@PathVariable String tagname, @RequestBody TagRequestDto tagRequestDto){
        Tag tag = tagService.convertToTag(tagRequestDto);
        Tag updatedTag = tagService.update(tagname, tag);
        return new ResponseEntity<TagResponseDto>(tagService.convertToTagResponseDto(updatedTag), HttpStatus.OK);
     }

     @DeleteMapping("/{tagname}")
    public ResponseEntity<Void> deleteTag(@PathVariable String tagname){
        tagService.delete(tagname);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
     }
}
