package com.blogify.entry.dtos.userDto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserPartialRequestDto {

    @Size(min = 3, max = 16, message = "Username must be between 3 to 16 characters")
    private  String username;

    @Size(min = 6, max = 15, message = "Password miust be between 6 to 15 characters")
    private  String password;

    @Email(message = "Email should be valid")
    private String email;

}
