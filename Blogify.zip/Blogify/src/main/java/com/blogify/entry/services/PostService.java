package com.blogify.entry.services;

import com.blogify.entry.dtos.userDto.UserAuthorResponseDto;
import com.blogify.entry.enteties.Post;
import com.blogify.entry.enteties.Tag;
import com.blogify.entry.enteties.User;
import com.blogify.entry.repositories.PostRepositories;
import com.blogify.entry.dtos.postDtos.PostRequestDtos;
import com.blogify.entry.dtos.postDtos.PostResponseDto;
import com.blogify.entry.repositories.TagsRepositories;
import com.blogify.entry.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PostService {

    @Autowired
    PostRepositories postRepositories;

    @Autowired
    TagsRepositories tagsRepositories;

    @Autowired
            @Lazy
    UserService userService;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ImageService imageService;

    private Set<Tag> persistTags(Set<Tag> tags){
        return tags.stream().map(tag -> tagsRepositories.findByName(tag.getName()).orElseGet(
                ()-> tagsRepositories.save(tag))).collect(Collectors.toSet());
    }

    public Post create(Post post, MultipartFile image, int userId){
        User user = userService.getById(userId);
        post.setTags(persistTags(post.getTags()));
        post.setUser(user);
        try {
            post.setImageUrl(imageService.saveImage(image));
        }catch (IOException| NoSuchAlgorithmException e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to upload image");
        }
        return postRepositories.save(post);
    }

    public Page<Post> getAll(int page, int size, String sortDirection,String sortBy){
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.fromString(sortDirection), sortBy));
        return postRepositories.findAll(pageable);
    }

    public List<Post> search(String value){
        return postRepositories.searchPosts(value);
    }

    public Post getPost(int id) {
        return postRepositories.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User with id " + id+ " not found"));
    }

    public List<Post> getByTitle(String title){
//        return postRepositories.findByTitle(title);
       return postRepositories.findByTitleContaining(title);
//       return postRepositories.findByTitleNative(title);
    }

    public List<Post> getByTagName(String tagName){
        return postRepositories.findByTagsName(tagName);
    }

    public Post update(int id, Post post, int userId){
        User user = userService.getById(userId);
        Post existingPost = user.getPosts().stream().filter(
                dbUser -> dbUser.getId() == id).findFirst().orElseThrow(
                () -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Post with id : "+ id+ " not found"));

        if(post.getTitle()!=null){
            existingPost.setTitle(post.getTitle());
        }
        if (post.getDescirption()!=null){
            existingPost.setDescirption(post.getDescirption());
        }
        if (post.getTags()!=null){
            existingPost.setTags(post.getTags());
        }
        return postRepositories.save(existingPost);
    }

    public void delete(int id, int userId){
        User user =userService.getById(userId);
        Post existingPost = user.getPosts().stream().filter(post -> post.getId() == id).findFirst().orElseThrow(
                () -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Post with id " +id+ " not found"));
        user.getPosts().removeIf(post -> post.getId()==id);
        existingPost.setTags(new HashSet<>());
        postRepositories.delete(existingPost);
        userRepository.save(user);
    }

    public List<Post> userPosts(int userId){
        User user = userService.getById(userId);
        return user.getPosts();
    }

    public Post covertToPost(PostRequestDtos postRequestDtos) {
        Post post = new Post();
        post.setTitle(postRequestDtos.getTitle());
        post.setDescirption(postRequestDtos.getDescirption());
        post.setTags(postRequestDtos.getTags().stream().map(tag ->
                new Tag(tag.toLowerCase())).collect(Collectors.toSet()));
        ;
        return post;
    }
    public PostResponseDto convertToPostResponseDtos(Post post) {
        PostResponseDto postResponseDto = new PostResponseDto();
        postResponseDto.setId(post.getId());
        postResponseDto.setTitle(post.getTitle());
        postResponseDto.setDescirption(post.getDescirption());
        postResponseDto.setTags(post.getTags().stream().map(Tag::getName)
                .collect(Collectors.toSet()));
        postResponseDto.setAuthor(convertToUserAuthorResponseDto(post.getUser()));
        postResponseDto.setCreatedDated(post.getCreatedDate());
        postResponseDto.setLastModifiedDate(post.getLastModifiedDate());
        postResponseDto.setImageUrl(post.getImageUrl());
        return postResponseDto;

    }

    public UserAuthorResponseDto convertToUserAuthorResponseDto(User user){
        UserAuthorResponseDto userAuthorResponseDto = new UserAuthorResponseDto();
        userAuthorResponseDto.setId(user.getId());
        userAuthorResponseDto.setUsername(user.getUsername());
        return userAuthorResponseDto;
    }

}

