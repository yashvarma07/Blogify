package com.blogify.entry.controllers;

import com.blogify.entry.services.EmailService;
import jakarta.persistence.Column;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EmailController {
    @Autowired
    EmailService emailService;

    @GetMapping("/email/sent")
    public ResponseEntity<String> sentEmail(
            @RequestParam String to,
            @RequestParam String subject,
            @RequestParam String body
    ){
        emailService.sendEmail(to,subject,body);
        return ResponseEntity.ok("Email Sent Successfully to "+ to);
    }
}
