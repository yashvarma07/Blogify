package com.blogify.entry.services;

import com.blogify.entry.enteties.User;
import com.blogify.entry.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.lang.ref.SoftReference;
import java.util.List;

@Service
public class EmailService {
    @Autowired
    private JavaMailSender javaMailSender;

    @Value("spring.mail.username")
    private String email;

    @Autowired
    UserRepository userRepository;

    @Async

    public void sendEmail(String to, String subject, String body){
        SimpleMailMessage message= new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);
        message.setFrom(email);
        javaMailSender.send(message);
        System.out.println("Email Sent Successfully To "+ to);
    }

    @Scheduled(cron = "30 45 20 * * ?")
//    @Scheduled(fixedRate = 1000)
    @Async
    public void sendPromotionalEmails(){
        List<User> users= userRepository.findAll();
        users.forEach(user -> sendEmail(user.getEmail(), "Unlock Your Blogging Potential with BlogHive!", getBody(user)));
    }

    public String getBody(User user){
        return "Dear " + user.getUsername() +
                ",\n" +
                "We appreciate your loyalty and want to treat you to something special! For a limited time, enjoy [discount or promotion details] on [product/service name].\n" +
                "\n" +
                "\uD83D\uDD25 Offer Details:\n" +
                "✅ [Discount or promo]\n" +
                "✅ Valid until [expiration date]\n" +
                "✅ Use code: [promo code] at checkout\n" +
                "\n" +
                "Don't miss out—grab this exclusive deal before it’s gone!\n" +
                "\n" +
                "[Shop Now] (or relevant CTA)\n" +
                "\n" +
                "Thank you for being a valued customer!\n" +
                "\n" +
                "Best,\n" +
                "[Your Name]\n" +
                "[Your Company Name]\n" +
                "[Your Contact Info]";
    }
}
